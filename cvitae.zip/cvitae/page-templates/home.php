<?php
/**
 * Template Name: CVitae Home
 *
 * @package CVitae
 * @since 1.0.0
 */

get_header(); ?>


	<?php
		/* 
		 * --------------------------------------
		 * Render CVitae Sections
		 * --------------------------------------
		 */
		cvitae_render_sections();
	?>

<?php
get_footer();